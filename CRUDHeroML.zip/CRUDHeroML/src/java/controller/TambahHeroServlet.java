package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.*;
import javax.servlet.http.*;
import koneksi.Koneksi;

public class TambahHeroServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String nama = request.getParameter("namaHero");
        String kategori = request.getParameter("kategori");
        String gender = request.getParameter("gender");

        try {
            Connection conn = Koneksi.getKoneksi();
            String sql = "INSERT INTO tm_hero (nama_hero, kategori, gender) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, nama);
            ps.setString(2, kategori);
            ps.setString(3, gender);
            ps.executeUpdate();

            response.sendRedirect("tampilHero.jsp");
        } catch (Exception e) {
            response.getWriter().println("Gagal menyimpan data: " + e.getMessage());
        }
    }
}
