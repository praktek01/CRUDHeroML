package controller;

import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import koneksi.Koneksi;

public class UpdateHeroServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");
        String nama = request.getParameter("namaHero");
        String kategori = request.getParameter("kategori");
        String gender = request.getParameter("gender");

        try {
            Connection conn = Koneksi.getKoneksi();
            String sql = "UPDATE tm_hero SET nama_hero=?, kategori=?, gender=? WHERE id_hero=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, nama);
            ps.setString(2, kategori);
            ps.setString(3, gender);
            ps.setString(4, id);
            ps.executeUpdate();

            response.sendRedirect("tampilHero.jsp");
        } catch (Exception e) {
            response.getWriter().println("Gagal update data: " + e.getMessage());
        }
    }
}
