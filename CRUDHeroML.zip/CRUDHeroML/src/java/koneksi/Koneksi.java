package koneksi;

import java.sql.Connection;
import java.sql.DriverManager;

public class Koneksi {
    public static Connection getKoneksi() {
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/db_mobilelegend",
                "root",
                ""
            );
        } catch (Exception e) {
            System.out.println("Koneksi gagal: " + e.getMessage());
        }
        return con;
    }
}
